package com.check24.book.api.bookstoreapi.dataint;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.check24.book.api.bookstoreapi.entity.Books;
import com.check24.book.api.bookstoreapi.repository.BookRepository;

@Component
public class DataInit implements ApplicationRunner {


    private BookRepository bookRepository;
    private static final Logger logger = LoggerFactory.getLogger(DataInit.class);

    @Autowired
    public DataInit(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        InputStream template = DataInit.class.getResourceAsStream("/data/books.csv");
        String line = "";
        String cvsSplitBy = ",";
        ClassLoader classLoader = getClass().getClassLoader();

        // BufferedReader br = new BufferedReader(new File(template));
        try (BufferedReader br = new BufferedReader(new InputStreamReader(template))) {

            while ((line = br.readLine()) != null) {

                logger.info("DataInit AMIT GARG BOOK line", line);

                // use comma as separatory
                String[] book = line.split(cvsSplitBy);

                // logger.info("DataInit AMIT GARG BOOK", book[0]);
                // logger.debug("Country [code= " + book[1] + " , name=" + book[2] + "]");

                Books bookEntity = new Books();

                // bookEntity.setId(book[0]);
                // bookEntity.setName(book[1]);
                // bookEntity.setDetails(book[2]);
                // bookEntity.setPrice(book[3]);
                // bookEntity.setImage(book[4]);

                bookEntity.setId("b1");
                bookEntity.setName("Textbook A:  Unit testing basic principles");
                bookEntity.setDetails("lorem");
                bookEntity.setPrice("ipsum");
                bookEntity.setImage("https://bilder.buecher.de/produkte/42/42530/42530510z.jpg");

                this.bookRepository.save(bookEntity);

            }

        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}
