package com.check24.book.api.bookstoreapi.mapper;

import java.util.List;

import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

import com.check24.book.api.bookstoreapi.entity.Books;
import com.check24.book.api.bookstoreapi.vo.BooksVo;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE, componentModel = "spring")
public interface BooksMapper {

    BooksVo mapEntityToDto(Books book);

    Books mapVoToEntity(BooksVo personVo);

    @BeanMapping(resultType = List.class)
    List<BooksVo> mapAsBooksVoList(List<Books> books);

    @BeanMapping(resultType = List.class)
    List<BooksVo> mapAsBooksVoList(Iterable<Books> books);
}
