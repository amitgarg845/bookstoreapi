package com.check24.book.api.bookstoreapi.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.check24.book.api.bookstoreapi.entity.Books;

@Repository
public interface BookRepository extends CrudRepository<Books, String> {

}
