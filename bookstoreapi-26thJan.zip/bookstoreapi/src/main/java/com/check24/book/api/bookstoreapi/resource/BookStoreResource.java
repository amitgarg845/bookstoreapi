package com.check24.book.api.bookstoreapi.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.check24.book.api.bookstoreapi.service.BookService;
import com.check24.book.api.bookstoreapi.vo.BooksResponseVo;
import com.check24.book.api.bookstoreapi.vo.BooksVo;

@RestController
@CrossOrigin
public class BookStoreResource {

    @Autowired
    BookService bookService;

    @GetMapping(value = "/task/books")
    public ResponseEntity<BooksResponseVo> getBooksLists() {
        BooksResponseVo booksResponseVo = this.bookService.getBooksList();
        return new ResponseEntity<>(booksResponseVo, HttpStatus.OK);
    }

    @GetMapping(value = "/task/details/{id}")
    public ResponseEntity<BooksVo> getBooksDetail(@PathVariable String id) {
        BooksVo booksVo = this.bookService.getBookDetails(id);
        return new ResponseEntity<>(booksVo, HttpStatus.OK);
    }

}
