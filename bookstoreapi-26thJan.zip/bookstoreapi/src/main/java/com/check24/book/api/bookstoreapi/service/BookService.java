package com.check24.book.api.bookstoreapi.service;

import com.check24.book.api.bookstoreapi.vo.BooksResponseVo;
import com.check24.book.api.bookstoreapi.vo.BooksVo;


public interface BookService {

    public BooksResponseVo getBooksList();

    public BooksVo getBookDetails(String id);
}
