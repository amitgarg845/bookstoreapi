package com.check24.book.api.bookstoreapi.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.check24.book.api.bookstoreapi.entity.Books;
import com.check24.book.api.bookstoreapi.mapper.BooksMapper;
import com.check24.book.api.bookstoreapi.repository.BookRepository;
import com.check24.book.api.bookstoreapi.service.BookService;
import com.check24.book.api.bookstoreapi.vo.BooksResponseVo;
import com.check24.book.api.bookstoreapi.vo.BooksVo;

@Service
public class BookServiceImpl implements BookService {

    @Autowired
    BookRepository bookRepository;

    @Autowired
    BooksMapper booksMapper;

    @Override
    public BooksResponseVo getBooksList() {

        BooksResponseVo booksResponseVo = new BooksResponseVo();
        booksResponseVo.setBooks(this.booksMapper.mapAsBooksVoList(this.bookRepository.findAll()));

        return booksResponseVo;
    }

    @Override
    public BooksVo getBookDetails(String id) {
        Optional<Books> optional = this.bookRepository.findById(id);
        BooksVo booksVo = null;
        if (optional.isPresent()) {
            booksVo = this.booksMapper.mapEntityToDto(optional.get());
        }
        return booksVo;
    }

}
