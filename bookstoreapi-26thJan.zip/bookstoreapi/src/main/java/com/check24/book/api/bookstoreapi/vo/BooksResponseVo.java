package com.check24.book.api.bookstoreapi.vo;

import java.util.List;

public class BooksResponseVo {

    List<BooksVo> books;

    public List<BooksVo> getBooks() {
        return this.books;
    }

    public void setBooks(List<BooksVo> books) {
        this.books = books;
    }

}
