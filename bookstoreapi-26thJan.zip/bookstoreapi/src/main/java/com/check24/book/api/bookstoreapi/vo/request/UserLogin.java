package com.check24.book.api.bookstoreapi.vo.request;

public class UserLogin {

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPasword() {
        return this.pasword;
    }

    public void setPasword(String pasword) {
        this.pasword = pasword;
    }
    String email;
    String pasword;

}
